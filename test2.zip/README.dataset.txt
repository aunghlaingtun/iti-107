# assingment2024 > 2024-12-23 1:18am
https://universe.roboflow.com/leatun/assingment2024

Provided by a Roboflow user
License: CC BY 4.0

