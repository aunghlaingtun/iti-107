# 631920G-iti-107 > 2024-12-21 8:37pm
https://universe.roboflow.com/leatun/631920g-iti-107

Provided by a Roboflow user
License: CC BY 4.0

