# 631920G-iti-107 > 2024-12-21 11:57pm
https://universe.roboflow.com/leatun/631920g-iti-107

Provided by a Roboflow user
License: CC BY 4.0

