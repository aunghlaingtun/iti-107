# 631920G-iti-107 > 2024-12-20 1:18am
https://universe.roboflow.com/leatun/631920g-iti-107

Provided by a Roboflow user
License: CC BY 4.0

