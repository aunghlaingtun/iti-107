# assingment2024 > 2024-12-22 11:16pm
https://universe.roboflow.com/leatun/assingment2024

Provided by a Roboflow user
License: CC BY 4.0

